from pytube import YouTube
yt = YouTube("http://ydgdudcvdcvdfv")
vedio = yt.streams.get_highest_resolution()
vedio.download()